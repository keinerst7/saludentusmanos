const db = require('../config/db');

class dispositivo_SaludModelo {
    // Obtener todos los dispositivos con paginación
    static async todosDispositivos(pagina = 1, limite = 10) {
        const offset = (pagina - 1) * limite;
        const query = 'SELECT * FROM dispositivo_salud LIMIT ? OFFSET ?';
        return db.query(query, [limite, offset]);
    }

    // Buscar un dispositivo por ID
    static async buscarPorId(id) {
        const query = 'SELECT * FROM dispositivo_salud WHERE id_dispositivo = ?';
        const [result] = await db.query(query, [id]);
        return result.length ? result[0] : null;
    }

    // Crear un nuevo dispositivo
    static async crearDispositivo({ usuario_id, nombre_dispositivo, tipo_dispositivo }) {
        const query = `
            INSERT INTO dispositivo_salud (usuario_id, nombre_dispositivo, tipo_dispositivo)
            VALUES (?, ?, ?)`;
        const [result] = await db.query(query, [usuario_id, nombre_dispositivo, tipo_dispositivo]);
        return { id_dispositivo: result.insertId, usuario_id, nombre_dispositivo, tipo_dispositivo };
    }

    // Eliminar un dispositivo por ID
    static async eliminarDispositivo(id) {
        const query = 'DELETE FROM dispositivo_salud WHERE id_dispositivo = ?';
        return db.query(query, [id]);
    }
}

module.exports = dispositivo_SaludModelo;