
const dbService = require('./bd/Conexion');

class usuariosModelo {
  // Obtener todos los usuarios con paginación
  static async todoUsuario(pagina = 1) {
    const limite = 50;  // Número máximo de productos por página
    const offset = (pagina - 1) * limite;  // Calculamos el offset para la paginación
    const query = `SELECT * FROM usuarios ORDER BY id ASC LIMIT ${limite} OFFSET ${offset}`;
    try {
      return await dbService.query(query);
    } catch (err) {
      throw new Error(`Error al obtener los usuarios: ${err.message}`);
    }
  }

  // Buscar usuario por ID
  static async buscarPorId(id) {
    const query = 'SELECT * FROM usuarios WHERE id = ?';
    try {
      const [user] = await dbService.query(query, [id]);
      return user || null;  // Devuelve null si no hay usuario
    } catch (err) {
      throw new Error(`Error al buscar el usuario por id: ${err.message}`);
    }
  }

  // Buscar usuario por nombre
  static async buscarPorNombre(name) {
    const query = 'SELECT * FROM usuarios WHERE nombre LIKE ?';
    try {
      return await dbService.query(query, [`%${name}%`]);
    } catch (err) {
      throw new Error(`Error al buscar el usuario por nombre: ${err.message}`);
    }
  }

  // Buscar usuario por fecha de creacion
  static async buscarPorfecha(fecha) {
    const query = 'SELECT * FROM usuarios WHERE fecha_nacimiento LIKE ?';
    try {
      return await dbService.query(query, [`%${fecha}%`]);
    } catch (err) {
      throw new Error(`Error al buscar el usuario por fecha: ${err.message}`);
    }
  }

  // Buscar usuario por correo
  static async buscarPorCorreo(email) {
    const query = 'SELECT * FROM usuarios WHERE correo LIKE ?';
    try {
      return await dbService.query(query, [`%${email}%`]);
    } catch (err) {
      throw new Error(`Error al buscar el usuario por email: ${err.message}`);
    }
  }

  static async buscarPorContra(contrasena) {
    const query = 'SELECT * FROM usuarios WHERE contrasena LIKE ?';
    try {
      return await dbService.query(query, [`%${contrasena}%`]);
    } catch (err) {
      throw new Error(`Error al buscar el usuario por contrasena: ${err.message}`);
    }
  }


  // Crear un nuevo usuario
  static async crearUsuarios(id, name, fecha, email, contrasena) {
    const query = 'INSERT INTO usuarios (id, nombre, fecha_nacimiento, correo, contrasena) VALUES (?, ?, ?, ?, ?)';
    try {
      return await dbService.query(query, [id, name, fecha, email, contrasena, "usuario", "Activo"]);
    } catch (err) {
      throw new Error(`Error al crear el usuario: ${err.message}`);
    }
  }

  // Modificar un usuario existente
  static async modificarUsuario(id, name, fecha, email, contrasena) {
    const query = 'UPDATE usuarios SET nombre = ?, fecha_nacimiento = ?, correo = ?, contrasena = ? WHERE id = ?';
    try {
      return await dbService.query(query, [name, fecha, email, contrasena, id]);  // ✅ id al final
    } catch (err) {
      throw new Error(`Error al modificar el usuario: ${err.message}`);
    }
  }
  

  // Eliminar un usuario
  static async eliminarUsuario(id) {
    const query = 'DELETE FROM usuarios WHERE id = ?';
    try {
      return await dbService.query(query, [id]);
    } catch (err) {
      throw new Error(`Error al eliminar el usuario: ${err.message}`);
    }
  }
  
}

module.exports = usuariosModelo;
