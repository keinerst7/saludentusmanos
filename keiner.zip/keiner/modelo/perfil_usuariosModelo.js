const db = require('../config/db'); 



class perfil_usuariosControlador {
    static async ubicarPorId(req, res) {
        const { id } = req.params;
        try {
            const perfil = await perfil_usuariosModelo.ubicarPorId(id);
            if (perfil) {
                res.json(perfil);
            } else {
                res.status(404).json({ error: 'Perfil no encontrado' });
            }
        } catch (err) {
            res.status(500).json({ error: err.message });
        }
    }




    // Buscar perfiles por usuario_id
    static async buscarPorUsuarioId(usuario_id) {
        const query = 'SELECT * FROM perfil_usuarios WHERE usuario_id = ?';
        try {
            const [result] = await db.execute(query, [usuario_id]);
            return result;
        } catch (err) {
            throw new Error(`Error al buscar perfiles por usuario_id: ${err.message}`);
        }
    }

    // Crear un nuevo perfil de usuario
    static async crearPerfil({ usuario_id, foto_perfil, biografia, ubicacion, genero, objetivos_salud, condiciones_medicas, preferencias_alimentarias }) {
        const query = `
            INSERT INTO perfil_usuarios 
            (usuario_id, foto_perfil, biografia, ubicacion, genero, objetivos_salud, condiciones_medicas, preferencias_alimentarias) 
            VALUES (?, ?, ?, ?, ?, ?, ?, ?)
        `;
        try {
            const [result] = await db.execute(query, [usuario_id, foto_perfil, biografia, ubicacion, genero, objetivos_salud, condiciones_medicas, preferencias_alimentarias]);
            return { id_perfil: result.insertId, usuario_id, foto_perfil, biografia, ubicacion, genero, objetivos_salud, condiciones_medicas, preferencias_alimentarias };
        } catch (err) {
            throw new Error(`Error al crear el perfil de usuario: ${err.message}`);
        }
    }

    // Actualizar un perfil de usuario
    static async actualizarPerfil(id_perfil, datos) {
        const query = `
            UPDATE perfil_usuarios 
            SET foto_perfil = ?, biografia = ?, ubicacion = ?, genero = ?, objetivos_salud = ?, condiciones_medicas = ?, preferencias_alimentarias = ? 
            WHERE id_perfil = ?
        `;
        try {
            const { foto_perfil, biografia, ubicacion, genero, objetivos_salud, condiciones_medicas, preferencias_alimentarias } = datos;
            const [result] = await db.execute(query, [foto_perfil, biografia, ubicacion, genero, objetivos_salud, condiciones_medicas, preferencias_alimentarias, id_perfil]);
            return result;
        } catch (err) {
            throw new Error(`Error al actualizar el perfil de usuario: ${err.message}`);
        }
    }

    // Eliminar un perfil de usuario por ID
    static async eliminarPerfil(id_perfil) {
        const query = 'DELETE FROM perfil_usuarios WHERE id_perfil = ?';
        try {
            const [result] = await db.execute(query, [id_perfil]);
            return result;
        } catch (err) {
            throw new Error(`Error al eliminar el perfil de usuario: ${err.message}`);
        }
    }
}

module.exports = perfil_usuariosControlador;
