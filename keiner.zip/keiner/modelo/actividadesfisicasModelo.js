class actividadesfisicasModelo {
    // Obtener todas las actividades físicas con paginación
    static async todasActividades(req, res) {
        const pagina = parseInt(req.query.pagina) || 1;
        console.log(`Consultando actividades físicas en la página: ${pagina}`);
        try {
            const actividades = await ActividadesFisicasModelo.todasActividades(pagina);
            console.log('Actividades obtenidas:', actividades);
            res.json(actividades);
        } catch (err) {
            console.error('Error al obtener actividades:', err);
            res.status(500).json({ error: 'Hubo un error al obtener las actividades físicas' });
        }
    }
    
    // Buscar actividad física por ID
    static async buscarPorId(id) {
        const query = `SELECT * FROM actividadesfisicas WHERE id = ?;`;

        try {
            console.log("Ejecutando consulta:", query);
            const [actividad] = await dbService.query(query, [id]);
            return actividad || null;
        } catch (err) {
            throw new Error(`Error al buscar la actividad física por ID: ${err.message}`);
        }
    }

    // Crear una nueva actividad física
    static async crearActividad(datos) {
        const query = `INSERT INTO actividadesfisicas (usuario_id, tipoactividad, duracionminutos, intensidad, calorias_quemadas) VALUES (?, ?, ?, ?, ?);`;

        
        try {
            return await dbService.query(query, [
                datos.usuario_id, 
                datos.tipo, 
                datos.duracion, 
                datos.intensidad, 
                datos.calorias_quemadas
            ]);
        } catch (err) {
            throw new Error(`Error al crear la actividad física: ${err.message}`);
        }
    }

    // Eliminar una actividad física por ID
    static async eliminarActividad(id) {
        const query = `DELETE FROM actividadesfisicas WHERE id = ?;`;

        try {
            return await dbService.query(query, [id]);
        } catch (err) {
            throw new Error(`Error al eliminar la actividad física: ${err.message}`);
        }
    }
}

module.exports = actividadesfisicasModelo;
