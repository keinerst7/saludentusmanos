const express = require('express');
const router = express.Router();
const actividadesfisicasControlador = require('../controlador/actividadesfisicasControlador');

// Obtener todas las actividades físicas con paginación
router.get('/', actividadesfisicasControlador.todasActividades);

// Buscar una actividad física por ID
router.get('/:id', actividadesfisicasControlador.buscarPorId);

// Crear una nueva actividad física
router.post('/', actividadesfisicasControlador.crearActividad);

// Eliminar una actividad física por ID
router.delete('/:id', actividadesfisicasControlador.eliminarActividad);

module.exports = router;
