const express = require('express');
const router = express.Router();
const dispositivo_saludControlador = require('../controlador/dispositivo_saludControlador'); 

module.exports = router;