const express = require('express');
const router = express.Router();
const perfil_usuariosControlador = require('../controlador/usuariosControlador'); 

// Obtener un perfil por su ID
router.get('/perfil/:id', (req, res) => {
    console.log('Ruta /perfil/:id alcanzada');
    perfil_usuariosControlador.buscarPorUsuario(req, res);
});

// Obtener perfiles por usuario_id
router.get('/usuario/:usuario_id', (req, res) => {
    console.log('Ruta /usuario/:usuario_id alcanzada');
    perfil_usuariosControlador.buscarUsuarioId(req, res);
});

// Crear un nuevo perfil
router.post('/perfil', (req, res) => {
    console.log('Ruta /perfil alcanzada');
    perfil_usuariosControlador.crearPerfil(req, res);
});

// Actualizar un perfil
router.put('/perfil/:id', (req, res) => {
    console.log('Ruta /perfil/:id alcanzada');
    perfil_usuariosControlador.actualizarPerfil(req, res);
});

module.exports = router;
