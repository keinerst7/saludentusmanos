// app.js
const express = require('express');
const bodyParser = require('body-parser');
const cors = require('cors');
const path = require('path');
const app = express();
const indexDia = require('./router/indexdia');
const usuariosRouter = require('./router/usuarios.js');
const perfilRouter = require('./router/perfil_usuarios.js');
const actfisicasRouter = require('./router/actividadesfisicas');

// Middleware
app.use(express.static(path.join(__dirname, 'public')));
app.use(bodyParser.json());
app.use(cors());

// Rutas
app.use('/', indexDia);
app.use('/registusuarios', usuariosRouter);
app.use('/perfil', perfilRouter);  // Asegúrate de que esta ruta esté correctamente configurada
app.use('/actfisicas', actfisicasRouter);

// Configuración del servidor
const PORT = 3050;
app.listen(PORT, () => {
    console.log(`Servidor escuchando en http://localhost:${PORT}`);
});
