const usuariosModelo = require('../modelo/usuariosModelo');

class UsuariosControlador {
  // Obtener todos los usuarios
  static async todoUsuario(req, res) {
    try {
      const users = await usuariosModelo.todoUsuario();
      res.json(users);
    } catch (err) {
      res.status(500).json({ error: 'Hubo un error al obtener los usuarios' });
    }
  }

  // Buscar usuario por ID
  static async buscarPorId(req, res) {
    const { id } = req.params;
    try {
      const user = await usuariosModelo.buscarPorId(id);
      if (!user) return res.status(404).json({ error: 'Usuario no encontrado' });
      res.json(user);
    } catch (err) {
      res.status(500).json({ error: 'Error al obtener el usuario' });
    }
  }

  // Buscar usuario por nombre
  static async buscarPorNombre(req, res) {
    const { name } = req.params;
    try {
      const users = await usuariosModelo.buscarPorNombre(name);
      if (!users.length) return res.status(404).json({ error: 'Usuario no encontrado' });
      res.json(users);
    } catch (err) {
      res.status(500).json({ error: 'Error al obtener el usuario' });
    }
  }

  // Buscar usuario por fecha
  static async buscarPorFecha(req, res) {
    const { fecha } = req.params;
    try {
      const users = await usuariosModelo.buscarPorfecha(fecha);
      if (!users.length) return res.status(404).json({ error: 'Usuario no encontrado' });
      res.json(users);
    } catch (err) {
      res.status(500).json({ error: 'Error al obtener el usuario' });
    }
  }

  // Buscar usuario por correo
  static async buscarPorCorreo(req, res) {
    const { email } = req.params;
    try {
      const users = await usuariosModelo.buscarPorCorreo(email);
      if (!users.length) return res.status(404).json({ error: 'Usuario no encontrado' });
      res.json(users);
    } catch (err) {
      res.status(500).json({ error: 'Error al obtener el usuario' });
    }
  }

  // Buscar usuario por contraseña
  static async buscarPorContra(req, res) {
    const { contrasena } = req.params;
    try {
      const users = await usuariosModelo.buscarPorContra(contrasena);
      if (!users.length) return res.status(404).json({ error: 'Usuario no encontrado' });
      res.json(users);
    } catch (err) {
      res.status(500).json({ error: 'Error al obtener el usuario' });
    }
  }

  // Crear un nuevo usuario
  static async crearUsuario(req, res) {
    const { id, name, fecha, email, contrasena } = req.body;
    try {
      const result = await usuariosModelo.crearUsuarios(id, name, fecha, email, contrasena);
      res.status(201).json({ message: 'Usuario creado', id: result.insertId });
    } catch (err) {
      res.status(500).json({ error: 'Error al crear el usuario' });
    }
  }

  // Modificar un usuario
  static async editarUsuario(req, res) {
    const { id } = req.params;
    const { name, fecha, email, contrasena } = req.body;
    try {
      const result = await usuariosModelo.modificarUsuario(id, name, fecha, email, contrasena);
      if (result.affectedRows === 0) return res.status(404).json({ error: 'Usuario no encontrado' });
      res.json({ message: 'Usuario actualizado' });
    } catch (err) {
      res.status(500).json({ error: 'Error al actualizar el usuario' });
    }
  }

  // Eliminar un usuario
  static async borrarUsuario(req, res) {
    const { id } = req.params;
    try {
      const result = await usuariosModelo.eliminarUsuario(id);
      if (result.affectedRows === 0) return res.status(404).json({ error: 'Usuario no encontrado' });
      res.json({ message: 'Usuario eliminado' });
    } catch (err) {
      res.status(500).json({ error: 'Error al eliminar el usuario' });
    }
  }
}

module.exports = UsuariosControlador;

