const perfil_usuariosModelo = require('../modelo/perfil_usuariosModelo');

class perfil_usuariosControlador {
    // Buscar perfil por ID
    static async buscarPerfId(req, res) {
        const { id } = req.params;
        try {
            const perfil = await perfil_usuariosModelo.buscarPerfId(id);
            if (!perfil) {
                return res.status(404).json({ error: 'Perfil no encontrado' });
            }
            res.json(perfil);
        } catch (err) {
            res.status(500).json({ error: `Error al obtener el perfil: ${err.message}` });
        }
    }

    // Buscar perfiles por usuario_id
    static async buscarUsuarioPorId(req, res) {
        const usuarioId = req.params.usuario_id;  // Extrae el usuario_id de los parámetros de la URL

        try {
            const perfiles = await perfil_usuariosModelo.buscarUsuarioPorId(usuarioId); // Aquí asegúrate de tener esta función en tu modelo

            if (!perfiles || perfiles.length === 0) {
                return res.status(404).json({ mensaje: 'No se encontraron perfiles para este usuario.' });
            }

            return res.status(200).json(perfiles);  // Devuelve los perfiles encontrados
        } catch (error) {
            console.error(error);
            return res.status(500).json({ mensaje: 'Error en el servidor al obtener perfiles.' });
        }
    }

    // Crear un nuevo perfil de usuario
    static async crearPerfil(req, res) {
        const { usuario_id, foto_perfil, biografia, ubicacion, genero, objetivos_salud, condiciones_medicas, preferencias_alimentarias } = req.body;
        try {
            const nuevoPerfil = await perfil_usuariosModelo.crearPerfil({
                usuario_id, foto_perfil, biografia, ubicacion, genero, objetivos_salud, condiciones_medicas, preferencias_alimentarias
            });
            res.status(201).json({ mensaje: 'Perfil creado con éxito', nuevoPerfil });
        } catch (err) {
            res.status(500).json({ error: `Error al crear el perfil: ${err.message}` });
        }
    }

    // Actualizar un perfil de usuario
    static async actualizarPerfil(req, res) {
        const { id } = req.params;
        const datos = req.body;
        try {
            const resultado = await perfil_usuariosModelo.actualizarPerfil(id, datos);
            if (resultado.affectedRows === 0) {
                return res.status(404).json({ error: 'Perfil no encontrado' });
            }
            res.json({ mensaje: 'Perfil actualizado con éxito' });
        } catch (err) {
            res.status(500).json({ error: `Error al actualizar el perfil: ${err.message}` });
        }
    }

    // Eliminar un perfil de usuario
    static async eliminarPerfil(req, res) {
        const { id } = req.params;
        try {
            const resultado = await perfil_usuariosModelo.eliminarPerfil(id);
            if (resultado.affectedRows === 0) {
                return res.status(404).json({ error: 'Perfil no encontrado' });
            }
            res.json({ mensaje: 'Perfil eliminado con éxito' });
        } catch (err) {
            res.status(500).json({ error: `Error al eliminar el perfil: ${err.message}` });
        }
    }
}

// Asegúrate de exportar la clase correctamente
module.exports = perfil_usuariosControlador;
