const DispositivoSaludModelo = require('../models/DispositivoSaludModelo');

class dispositivo_saludControlador {
    // Obtener todos los dispositivos con paginación
    static async obtenerTodos(req, res) {
        try {
            const { pagina = 1, limite = 10 } = req.query;
            const dispositivos = await DispositivoSaludModelo.todosDispositivos(Number(pagina), Number(limite));
            res.json({ success: true, data: dispositivos });
        } catch (error) {
            res.status(500).json({ success: false, message: error.message });
        }
    }

    // Obtener un dispositivo por ID
    static async obtenerPorId(req, res) {
        try {
            const { id } = req.params;
            const dispositivo = await DispositivoSaludModelo.buscarPorId(id);
            if (!dispositivo) {
                return res.status(404).json({ success: false, message: 'Dispositivo no encontrado' });
            }
            res.json({ success: true, data: dispositivo });
        } catch (error) {
            res.status(500).json({ success: false, message: error.message });
        }
    }

    // Crear un nuevo dispositivo
    static async crear(req, res) {
        try {
            const { usuario_id, nombre_dispositivo, tipo_dispositivo } = req.body;
            if (!usuario_id || !nombre_dispositivo || !tipo_dispositivo) {
                return res.status(400).json({ success: false, message: 'Todos los campos son requeridos' });
            }
            const nuevoDispositivo = await DispositivoSaludModelo.crearDispositivo({ usuario_id, nombre_dispositivo, tipo_dispositivo });
            res.status(201).json({ success: true, data: nuevoDispositivo });
        } catch (error) {
            res.status(500).json({ success: false, message: error.message });
        }
    }

    // Eliminar un dispositivo por ID
    static async eliminar(req, res) {
        try {
            const { id } = req.params;
            const resultado = await DispositivoSaludModelo.eliminarDispositivo(id);
            if (resultado.affectedRows === 0) {
                return res.status(404).json({ success: false, message: 'Dispositivo no encontrado' });
            }
            res.json({ success: true, message: 'Dispositivo eliminado correctamente' });
        } catch (error) {
            res.status(500).json({ success: false, message: error.message });
        }
    }
}

module.exports = dispositivo_saludControlador;
