const ActividadesFisicasModelo = require('../modelo/actividadesfisicasModelo');

class actividadesfisicasControlador {
    // Obtener todas las actividades físicas con paginación
    static async todasActividades(req, res) {
        const pagina = parseInt(req.query.pagina) || 1;
        try {
            const actividades = await ActividadesFisicasModelo.todasActividades(pagina);
            res.json(actividades);
        } catch (err) {
            res.status(500).json({ error: 'Hubo un error al obtener las actividades físicas' });
        }
    }

    // Buscar una actividad física por ID
    static async buscarPorId(req, res) {
        const { id } = req.params;
        try {
            const actividad = await ActividadesFisicasModelo.buscarPorId(id);
            if (!actividad) {
                return res.status(404).json({ error: 'Actividad física no encontrada' });
            }
            res.json(actividad);
        } catch (err) {
            res.status(500).json({ error: 'Hubo un error al buscar la actividad física' });
        }
    }

    // Crear una nueva actividad física
    static async crearActividad(req, res) {
        const { usuario_id, tipo, duracion, intensidad, calorias_quemadas } = req.body;
        if (!usuario_id || !tipo || !duracion || !intensidad || !calorias_quemadas) {
            return res.status(400).json({ error: 'Faltan datos obligatorios' });
        }

        try {
            const nuevaActividad = await ActividadesFisicasModelo.crearActividad({
                usuario_id, tipo, duracion, intensidad, calorias_quemadas
            });
            res.status(201).json({ mensaje: 'Actividad física creada con éxito', nuevaActividad });
        } catch (err) {
            res.status(500).json({ error: 'Hubo un error al crear la actividad física' });
        }
    }

    // Eliminar una actividad física por ID
    static async eliminarActividad(req, res) {
        const { id } = req.params;
        try {
            const resultado = await ActividadesFisicasModelo.eliminarActividad(id);
            if (resultado.affectedRows === 0) {
                return res.status(404).json({ error: 'Actividad física no encontrada' });
            }
            res.json({ mensaje: 'Actividad física eliminada correctamente' });
        } catch (err) {
            res.status(500).json({ error: 'Hubo un error al eliminar la actividad física' });
        }
    }
}

module.exports = actividadesfisicasControlador;